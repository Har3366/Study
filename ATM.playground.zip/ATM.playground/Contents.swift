import Foundation

// MARK: Абстракция данных пользователя
protocol UserData {
  var userName: String { get }    //Имя пользователя
  var userCardId: String { get }   //Номер карты
  var userCardPin: Int { get }       //Пин-код
  var userCash: Float {get set}   //Наличные пользователя
  var userBankDeposit: Float {get set}   //Банковский депозит
  var userPhone: String { get }       //Номер телефона
  var userPhoneBalance: Float {get set}    //Баланс телефона
}
// MARK: To Do! Тексты ошибок
enum TextErrors: String {
   
    case wrongPin = "Incorrect pin code or card number. Two attempts left"
    case wrongTelephoneNumber = "Sorry. Incorrect phone number"
    case wrongTelephoneNumberLength = "Sorry.Incorrect number of digits in the phone number"
    case notEnoughOnDeposit = "Sorry. You got insufficient funds on the deposit"
    case notEnoughCash = "Sorry. You don't have enough cash"
    case paymentMethodNotSelected = "You need to choose a payment method"
}

 
 // MARK: Виды операций, выбранных пользователем (подтверждение выбора)
enum DescriptionTypesAvailableOperations: String {
    
    case topUpPhoneBalanceCash = "You've chosen to deposit the phone balance in cash"
    case topUpPhoneBalanceDeposit = "You've chosen to deposit the phone balance from deposit"
    case balanceRequest = "You requested a balance"
    case putCashDeposit = "You've chosen to top up a deposit "
    case getCashFromDeposit = "You've chosen to withdraw funds from the deposit"
    
}
 
// MARK:Действия, которые пользователь может выбирать в банкомате (имитация кнопок)
enum UserActions {
    case showBalance
    case putCashDeposit
    case getCashFromDeposit
    case topUpPhoneBalance
}
 
// MARK:Способ оплаты/пополнения наличными или через депозит
enum PaymentMethod {
    case topUpPhoneBalanceCash
    case topUpPhoneBalanceDeposit
    
}

 //MARK: Банкомат, с которым мы работаем, имеет общедоступный интерфейс sendUserDataToBank
class ATM {
  private let userCardId: String // номер карты пользователя
  private let userCardPin: Int   // пин-код карты пользователя
  private var someBank: BankApi  //  structure от Банка
  private let action: UserActions // выбранное действие
  private let phoneNumber : String? // вводимый номер телефона пользователя. Сравнивается с имеющимся номером в базе Банка. Обязателен при пополнении его баланса
  private let transferAmount: Float? // Сумма выбранной транзакции
  private let paymentMethod: PaymentMethod? // Выбранный способ пополнение баланса телефона
  public final func sendUserDataToBank(userCardId: String, userCardPin: Int, actions: UserActions, payment: PaymentMethod?) {
    someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
     
    
   }
    
    init(userCardId: String, userCardPin: Int, action: UserActions,bank:BankApi,transferAmount: Float = 0.0,phoneNumber: String? = nil, paymentMethod: PaymentMethod? = nil) {
    self.userCardId = userCardId
    self.userCardPin = userCardPin
    self.someBank = bank
    self.action = action
    self.transferAmount = transferAmount
    self.paymentMethod=paymentMethod
    self.phoneNumber = phoneNumber

    if (someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)){
        
        switch action {
    case .getCashFromDeposit:
        if someBank.checkMaxAccountDeposit(withdraw: transferAmount){
            print (DescriptionTypesAvailableOperations.getCashFromDeposit.rawValue)
            someBank.showWithdrawalDeposit(cash: transferAmount)
            someBank.getCashFromDeposit(cash: transferAmount)
            
        } else {
            print (TextErrors.notEnoughOnDeposit.rawValue)
        }
        
    case .putCashDeposit:
        if someBank.checkMaxUserCash(cash: transferAmount){
            print (DescriptionTypesAvailableOperations.putCashDeposit.rawValue)
            someBank.showTopUpAccount(cash: transferAmount)
            someBank.putCashDeposit(topUp: transferAmount)
        } else {
            print(TextErrors.notEnoughCash.rawValue)
        }
    
    
    case .showBalance:
        print (DescriptionTypesAvailableOperations.balanceRequest.rawValue)
        someBank.showUserBalance()
        
        
    case .topUpPhoneBalance:
    
    if someBank.checkUserPhone(phone: phoneNumber){
       
        switch paymentMethod
        {
        case .topUpPhoneBalanceCash :
        if someBank.checkMaxUserCash(cash: transferAmount){
            print (DescriptionTypesAvailableOperations.topUpPhoneBalanceCash.rawValue)
            someBank.showUserToppedUpMobilePhoneCash(cash: transferAmount)
            someBank.putCashDeposit(topUp: transferAmount)
            someBank.topUpPhoneBalanceCash(pay: transferAmount)
        } else {
            print (TextErrors.notEnoughCash.rawValue)
        }
        
        case .topUpPhoneBalanceDeposit:
            if someBank.checkMaxAccountDeposit(withdraw: transferAmount){
            print (DescriptionTypesAvailableOperations.topUpPhoneBalanceDeposit.rawValue)
                someBank.showUserToppedUpMobilePhoneDeposite(deposit: transferAmount)
            someBank.showWithdrawalDeposit(cash: transferAmount)
            someBank.getCashFromDeposit(cash: transferAmount)
            someBank.topUpPhoneBalanceDeposit(pay: transferAmount)
        } else {
            print (TextErrors.notEnoughOnDeposit.rawValue)
        }
        case nil: print (TextErrors.paymentMethodNotSelected.rawValue)
        }
    } else {return}
        
        
        }
    }  else {
        print (TextErrors.wrongPin.rawValue)
    }
        
    sendUserDataToBank(userCardId:userCardId, userCardPin: userCardPin, actions: action, payment: paymentMethod )
  }
}

//MARK: Протокол по работе с банком предоставляет доступ к данным пользователя зарегистрированного в банке
protocol BankApi {
  func showUserBalance()
  func showUserToppedUpMobilePhoneCash(cash: Float)
  func showUserToppedUpMobilePhoneDeposite(deposit: Float)
  func showWithdrawalDeposit(cash: Float)
  func showTopUpAccount(cash: Float)
  func showError(error: TextErrors)
 
  func checkUserPhone(phone: String?) -> Bool
  func checkMaxUserCash(cash: Float) -> Bool
  func checkMaxAccountDeposit(withdraw: Float) -> Bool
  func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
 
  mutating func topUpPhoneBalanceCash(pay: Float)
  mutating func topUpPhoneBalanceDeposit(pay: Float)
  mutating func getCashFromDeposit(cash: Float)
  mutating func putCashDeposit(topUp: Float)
}


class Consumer : UserData {
    
    private (set) var userName: String
    private (set) var userCardId: String
    private (set) var userPhone: String
    private (set) var userCardPin: Int
    
    var userCash: Float
    var userBankDeposit: Float
    var userPhoneBalance: Float
    
    init (userName: String,userCardId: String, userCardPin: Int, userCash: Float, userBankDeposit: Float, userPhone: String,userPhoneBalance: Float){
        self.userName = userName
        self.userCardId = userCardId
        self.userCardPin = userCardPin
        self.userCash = userCash
        self.userBankDeposit = userBankDeposit
        self.userPhone = userPhone
        self.userPhoneBalance = userPhoneBalance
        }
    
}

struct Bank : BankApi {
    
    var userDepositBalance: Float
    var userPhoneBalance : Float
    var userTelephoneNumber : String
    var userCash: Float
    let userCardId : String
    let userCardPin : Int
    
    init (user: UserData){
        userDepositBalance = user.userBankDeposit
        userPhoneBalance = user.userPhoneBalance
        userTelephoneNumber = user.userPhone
        userCardId = user.userCardId
        userCardPin = user.userCardPin
        userCash = user.userCash
    }
    
    func showUserBalance() {
        print ("Your deposit balance is \(userDepositBalance) ye now")
    }
    
    func showUserToppedUpMobilePhoneCash(cash: Float) {
        print ("Your phone balance is \(userPhoneBalance+cash) ye now")
    }
    
    func showUserToppedUpMobilePhoneDeposite(deposit: Float) {
        print ("Your phone balance is \(userPhoneBalance+deposit) ye now")
    }
    
    func showWithdrawalDeposit(cash: Float) {
        print ("Account balance is \(userDepositBalance-cash) ye now")
    }
    
    func showTopUpAccount(cash: Float) {
        print ("Account balance is \(userDepositBalance+cash) ye now")
    }
    
    func showError(error: TextErrors) {
        print (error)
    }
    
    func checkUserPhone(phone: String?) -> Bool {
        
        if phone == nil{
            print (TextErrors.wrongTelephoneNumberLength.rawValue)
            return false
        } else
        if phone != userTelephoneNumber{
            print (TextErrors.wrongTelephoneNumber.rawValue)
            return false
        }
        return true
            
    }
    
    func checkMaxUserCash(cash: Float) -> Bool {
        if cash <= userCash{
            return true
        } else{
            return false
        }
    }
    
    func checkMaxAccountDeposit(withdraw: Float) -> Bool {
        if withdraw<=userDepositBalance{
            return true
        }
        else {
            return false
        }
    }
    
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
        if self.userCardId == userCardId && self.userCardPin == userCardPin{
            return true
        } else {
            return false
        }
    }
    
    mutating func topUpPhoneBalanceCash(pay: Float) {
        userPhoneBalance+=pay
        userCash-=pay
    }
    
    mutating func topUpPhoneBalanceDeposit(pay: Float) {
        userPhoneBalance+=pay
        userDepositBalance-=pay
    }
    
    mutating func getCashFromDeposit(cash: Float) {
        userDepositBalance-=cash
        userCash+=cash
    }
    
    mutating func putCashDeposit(topUp: Float) {
        userDepositBalance+=topUp
        userCash-=topUp
    }
}

let consumer1 = Consumer(userName: "Poly", userCardId: "3344 6600 4567 0090", userCardPin: 1234, userCash: 678.90, userBankDeposit: 15.00, userPhone: "+207203344", userPhoneBalance: 679.38)

let veryBigBank = Bank(user: consumer1)

// Весь инициализатор АТМ для наглядности
//init(userCardId: String, userCardPin: Int, action: UserActions,bank:BankApi,transferAmount: Float = 0.0,phoneNumber: String? = nil, paymentMethod: PaymentMethod? = nil)

// Примеры
//let atm124 = ATM(userCardId: "3344 6600 4567 0090", userCardPin: 1234, action: .showBalance, bank: veryBigBank,transferAmount: 10.62,paymentMethod: .topUpPhoneBalanceCash)
//let atm123 = ATM(userCardId: "3344 6600 4567 0090", userCardPin: 1234, action: .getCashFromDeposit, bank: veryBigBank, transferAmount: 20)

//let atm122 = ATM(userCardId: "3344 6600 4567 0090", userCardPin: 1234, action:.putCashDeposit, bank: veryBigBank,transferAmount: 70)
//let atm178 = ATM(userCardId: "3344 6600 4567 0090", userCardPin: 1234, action: .topUpPhoneBalance, bank: veryBigBank, transferAmount: 100, phoneNumber: "+207203344")
//
//let atm179 = ATM(userCardId: "3344 6600 4567 0090", userCardPin: 1234, action: .topUpPhoneBalance, bank: veryBigBank, transferAmount: 105, phoneNumber: "+207203344",paymentMethod: .topUpPhoneBalanceCash)
